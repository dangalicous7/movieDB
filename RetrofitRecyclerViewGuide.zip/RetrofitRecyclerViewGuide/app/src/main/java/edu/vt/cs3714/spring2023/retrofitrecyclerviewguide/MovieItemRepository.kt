package edu.vt.cs3714.spring2023.retrofitrecyclerviewguide

import androidx.annotation.WorkerThread
import androidx.lifecycle.LiveData

class MovieItemRepository (private val movieDao: MovieItemDao) {

    val allMoviesByTitle: LiveData<List<MovieItem>> = movieDao.getAllMoviesByTitle()
    val allMoviesByRating: LiveData<List<MovieItem>> = movieDao.getAllMoviesByRating()
    //val allMovies: LiveData<List<MovieItem>> = movieDao.getAllMovies()

    @WorkerThread
    fun insert(movie: MovieItem) {


        movieDao.insertMovie(movie)
    }

    @WorkerThread
    fun deleteAll() {
        movieDao.deleteAll()
    }
}

