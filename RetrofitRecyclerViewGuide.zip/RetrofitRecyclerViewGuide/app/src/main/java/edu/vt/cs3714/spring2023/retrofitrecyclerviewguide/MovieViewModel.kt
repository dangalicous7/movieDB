package edu.vt.cs3714.spring2023.retrofitrecyclerviewguide

import android.app.Application
import android.graphics.Movie
import android.util.Log
import androidx.lifecycle.AndroidViewModel
import androidx.lifecycle.LiveData
import io.reactivex.android.schedulers.AndroidSchedulers
import io.reactivex.disposables.Disposable
import io.reactivex.schedulers.Schedulers
import kotlinx.coroutines.CoroutineScope
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.Job
import kotlinx.coroutines.launch
import kotlin.coroutines.CoroutineContext

class MovieViewModel (application : Application) : AndroidViewModel(application) {
    //Update this with your API KEY
    private val api_key = "1410abaefa7ece790acf735ea5807c7b"
    private val api_base_url = "https://api.themoviedb.org/3/"

    private var parentJob = Job()
    private val coroutineContext: CoroutineContext
        get() = parentJob + Dispatchers.Main
    private val scope = CoroutineScope(coroutineContext)


    private var disposable: Disposable? = null
    private val repository: MovieItemRepository
    //var allMovies: LiveData<List<MovieItem>>
    var allMoviesByTitle: LiveData<List<MovieItem>>
    var allMoviesByRating: LiveData<List<MovieItem>>
    var favorites: MutableList<String> = mutableListOf()

    init {
        val moviesDao = MovieRoomDatabase.getDatabase(application).movieDao()
        repository = MovieItemRepository(moviesDao)
        //allMovies = repository.allMovies
        allMoviesByTitle = repository.allMoviesByTitle
        allMoviesByRating = repository.allMoviesByRating
    }
    fun refreshMovies(page: Int){
        disposable =
            RetrofitService.create("https://api.themoviedb.org/3/").getNowPlaying(api_key,page).subscribeOn(
                Schedulers.io()).observeOn(
                AndroidSchedulers.mainThread()).subscribe(
                {result -> showResult(result)},
                {error -> showError(error)})
    }

    fun addToFavorites(title: String?) {

        Log.d("Adding", favorites.size.toString())
        if (title != null) {
            favorites.add(title)
        }
        Log.d("Adding", favorites.size.toString())

    }

    fun removeFromFavorites(title: String?) {

        Log.d("Removing", favorites.size.toString())
        favorites.remove(title)
        Log.d("Removing", favorites.size.toString())

    }

    private fun showError(error: Throwable?) {
        Log.d("t04","Error:"+error?.toString())
    }

    private fun showResult(result: Movies?) {

        Log.d("T04","Page:"+result?.page+"Result:"+result?.results?.last()?.release_date+ " pages "+ result?.total_pages)
        deleteAll()

        result?.results?.forEach { movie ->
            insert(movie)
        }
    }

    private fun insert(movie: MovieItem) = scope.launch(Dispatchers.IO) {
        repository.insert(movie)
    }

    private fun deleteAll() = scope.launch (Dispatchers.IO){
        repository.deleteAll()
    }
}


